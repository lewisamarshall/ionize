import sys
import os
import shelve
import json


def get_db(flag='r'):
    """Opens the ion database and returns it as a shelve.

    By default opens in write-only state. Pass in a different flag for write
    access.

    Because the database is housed in a file, be sure to close when done.
    """
    # if sys.platform == 'win32' or sys.version_info[0] == 3:
    #     db_name = 'ions_shelve.bin'
    # else:
    #     db_name = 'ions_shelve.db'

    db_name = 'ions_db.json'
    path = os.path.join(os.getcwd(), os.path.dirname(__file__), db_name)


    with open(path, 'r') as fp:
        ion_list = json.load(fp)
    # ion_list = shelve.open(path, flag=flag)
    return ion_list

if __name__ == '__main__':
    ion_list = get_db()
    print len(ion_list), 'ions in database.'
    print ion_list['hydrochloric acid']
    # ion_list.close()
